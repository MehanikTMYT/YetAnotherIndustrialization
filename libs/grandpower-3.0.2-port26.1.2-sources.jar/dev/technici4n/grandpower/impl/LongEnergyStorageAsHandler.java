/*
 * MIT License
 *
 * Copyright (c) 2020 Azercoco & Technici4n
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR DEALINGS IN THE
 * SOFTWARE.
 */
package dev.technici4n.grandpower.impl;

import com.google.common.primitives.Ints;
import dev.technici4n.grandpower.api.ILongEnergyStorage;
import net.neoforged.neoforge.transfer.energy.EnergyHandler;
import net.neoforged.neoforge.transfer.transaction.TransactionContext;
import org.jetbrains.annotations.ApiStatus;

/**
 * Adapts an {@link ILongEnergyStorage} to the NeoForge 26 {@link EnergyHandler} API.
 */
@ApiStatus.Internal
public final class LongEnergyStorageAsHandler implements EnergyHandler {
    private final ILongEnergyStorage storage;

    public LongEnergyStorageAsHandler(ILongEnergyStorage storage) {
        this.storage = storage;
    }

    @Override
    public long getAmountAsLong() {
        return storage.getAmount();
    }

    @Override
    public long getCapacityAsLong() {
        return storage.getCapacity();
    }

    @Override
    public int insert(int amount, TransactionContext transaction) {
        long received = storage.receive(amount, false);
        return Ints.saturatedCast(received);
    }

    @Override
    public int extract(int amount, TransactionContext transaction) {
        long extracted = storage.extract(amount, false);
        return Ints.saturatedCast(extracted);
    }

    @Override
    public String toString() {
        return "LongEnergyStorageAsHandler[" + storage + "]";
    }
}
