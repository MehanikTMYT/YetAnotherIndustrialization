package dev.technici4n.grandpower.impl;

import dev.technici4n.grandpower.api.ILongEnergyStorage;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.ModContainer;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.ICapabilityProvider;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.transfer.access.ItemAccess;
import net.neoforged.neoforge.transfer.energy.EnergyHandler;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * GrandPower mod entry point (ported to NeoForge 26.1.2).
 * <p>
 * Keeps the {@code dev.technici4n.grandpower.*} API surface so existing dependents
 * (e.g. YetAnotherIndustrialization) keep working, while adapting to the NeoForge 26
 * energy capability ({@link EnergyHandler}) under the hood.
 */
@ApiStatus.Internal
@Mod(GrandPowerImpl.MOD_ID)
public class GrandPowerImpl {
    public static final String MOD_ID = "grandpower";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    public GrandPowerImpl(IEventBus modBus, ModContainer modContainer) {
        modBus.addListener(EventPriority.LOW, GrandPowerImpl::initCapabilities);
    }

    private static void initCapabilities(RegisterCapabilitiesEvent event) {
        registerBlockWrapper(event);
        registerEntityWrapper(event);
        registerItemWrapper(event);
    }

    private static ILongEnergyStorage wrapBlock(Level level, net.minecraft.core.BlockPos pos, BlockState state,
            @Nullable BlockEntity blockEntity, @Nullable Direction direction) {
        EnergyHandler forge = Capabilities.Energy.BLOCK.getCapability(level, pos, state, blockEntity, direction);
        return forge == null ? null : new EnergyHandlerAdapter(forge);
    }

    private static EnergyHandler wrapBlockToForge(Level level, net.minecraft.core.BlockPos pos, BlockState state,
            @Nullable BlockEntity blockEntity, @Nullable Direction direction) {
        ILongEnergyStorage longStorage = ILongEnergyStorage.BLOCK.getCapability(level, pos, state, blockEntity, direction);
        return longStorage == null ? null : new LongEnergyStorageAsHandler(longStorage);
    }

    private static void registerBlockWrapper(RegisterCapabilitiesEvent event) {
        // Block capability
        var allBlocks = BuiltInRegistries.BLOCK.stream().toArray(Block[]::new);
        ThreadLocal<Boolean> inBlockCompat = ThreadLocal.withInitial(() -> false);

        // ILongEnergyStorage <---> Forge Energy (EnergyHandler) block wrappers
        event.registerBlock(ILongEnergyStorage.BLOCK, (level, pos, state, be, direction) -> {
            if (inBlockCompat.get()) {
                return null;
            }

            inBlockCompat.set(Boolean.TRUE);
            try {
                return wrapBlock(level, pos, state, be, direction);
            } finally {
                inBlockCompat.set(Boolean.FALSE);
            }
        }, allBlocks);

        event.registerBlock(Capabilities.Energy.BLOCK, (level, pos, state, be, direction) -> {
            if (inBlockCompat.get()) {
                return null;
            }

            inBlockCompat.set(Boolean.TRUE);
            try {
                return wrapBlockToForge(level, pos, state, be, direction);
            } finally {
                inBlockCompat.set(Boolean.FALSE);
            }
        }, allBlocks);
    }

    private static void registerEntityWrapper(RegisterCapabilitiesEvent event) {
        // Entity capability
        ThreadLocal<Boolean> inEntityCompat = ThreadLocal.withInitial(() -> false);

        ICapabilityProvider<Entity, @Nullable Direction, ILongEnergyStorage> fromForgeEnergy = (entity, direction) -> {
            if (inEntityCompat.get()) {
                return null;
            }

            inEntityCompat.set(Boolean.TRUE);
            try {
                EnergyHandler forge = entity.getCapability(Capabilities.Energy.ENTITY, direction);
                return forge == null ? null : new EnergyHandlerAdapter(forge);
            } finally {
                inEntityCompat.set(Boolean.FALSE);
            }
        };

        ICapabilityProvider<Entity, @Nullable Direction, EnergyHandler> toForgeEnergy = (entity, direction) -> {
            if (inEntityCompat.get()) {
                return null;
            }

            inEntityCompat.set(Boolean.TRUE);
            try {
                ILongEnergyStorage longStorage = entity.getCapability(ILongEnergyStorage.ENTITY, direction);
                return longStorage == null ? null : new LongEnergyStorageAsHandler(longStorage);
            } finally {
                inEntityCompat.set(Boolean.FALSE);
            }
        };

        for (var entityType : BuiltInRegistries.ENTITY_TYPE) {
            event.registerEntity(ILongEnergyStorage.ENTITY, entityType, fromForgeEnergy);
            event.registerEntity(Capabilities.Energy.ENTITY, entityType, toForgeEnergy);
        }
    }

    private static void registerItemWrapper(RegisterCapabilitiesEvent event) {
        // Item capability
        var allItems = BuiltInRegistries.ITEM.stream().toArray(Item[]::new);
        ThreadLocal<Boolean> inItemCompat = ThreadLocal.withInitial(() -> false);

        event.registerItem(ILongEnergyStorage.ITEM, (stack, ignored) -> {
            if (inItemCompat.get()) {
                return null;
            }

            inItemCompat.set(Boolean.TRUE);
            try {
                EnergyHandler forge = Capabilities.Energy.ITEM.getCapability(stack, ItemAccess.forStack(stack));
                return forge == null ? null : new EnergyHandlerAdapter(forge);
            } finally {
                inItemCompat.set(Boolean.FALSE);
            }
        }, allItems);

        event.registerItem(Capabilities.Energy.ITEM, (stack, ignored) -> {
            if (inItemCompat.get()) {
                return null;
            }

            inItemCompat.set(Boolean.TRUE);
            try {
                // ILongEnergyStorage.ITEM is createVoid (context == Void), so pass null context.
                ILongEnergyStorage longStorage = ILongEnergyStorage.ITEM.getCapability(stack, null);
                return longStorage == null ? null : new LongEnergyStorageAsHandler(longStorage);
            } finally {
                inItemCompat.set(Boolean.FALSE);
            }
        }, allItems);
    }
}
