/*
 * MIT License
 *
 * Copyright (c) 2020 Azercoco & Technici4n
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package dev.technici4n.grandpower.impl;

import com.google.common.primitives.Ints;
import dev.technici4n.grandpower.api.ILongEnergyStorage;
import net.neoforged.neoforge.transfer.energy.EnergyHandler;
import net.neoforged.neoforge.transfer.transaction.Transaction;
import org.jetbrains.annotations.ApiStatus;

/**
 * Adapts a NeoForge 26 {@link EnergyHandler} to the {@link ILongEnergyStorage} API.
 * <p>
 * {@code receive}/ {@code extract} with {@code simulate == true} open a root
 * transaction and abort it (roll back); with {@code simulate == false} the
 * transaction is committed.
 */
@ApiStatus.Internal
public final class EnergyHandlerAdapter implements ILongEnergyStorage {
    private final EnergyHandler handler;

    public EnergyHandlerAdapter(EnergyHandler handler) {
        this.handler = handler;
    }

    @Override
    public long receive(long maxReceive, boolean simulate) {
        int amount = Ints.saturatedCast(maxReceive);
        try (Transaction tx = Transaction.openRoot()) {
            int inserted = handler.insert(amount, tx);
            if (simulate) {
                // abort: close() without commit rolls back
                return inserted;
            }
            tx.commit();
            return inserted;
        }
    }

    @Override
    public long extract(long maxExtract, boolean simulate) {
        int amount = Ints.saturatedCast(maxExtract);
        try (Transaction tx = Transaction.openRoot()) {
            int extracted = handler.extract(amount, tx);
            if (simulate) {
                return extracted;
            }
            tx.commit();
            return extracted;
        }
    }

    @Override
    public long getAmount() {
        return handler.getAmountAsLong();
    }

    @Override
    public long getCapacity() {
        return handler.getCapacityAsLong();
    }

    @Override
    public boolean canExtract() {
        // EnergyHandler has no canExtract; always try (extract returns 0 if not possible)
        return true;
    }

    @Override
    public boolean canReceive() {
        return true;
    }

    @Override
    public String toString() {
        return "EnergyHandlerAdapter[" + handler + "]";
    }
}
